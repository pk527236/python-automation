import boto3
from datetime import datetime, timedelta

# Replace with your SNS Topic ARN
SNS_TOPIC_ARN = 'arn:aws:sns:ap-south-1:165066919250:security-alerts'

def check_iam_users_without_mfa():
    iam = boto3.client('iam')
    users = iam.list_users()['Users']
    users_without_mfa = []

    for user in users:
        username = user['UserName']
        try:
            iam.get_login_profile(UserName=username)
            mfa_devices = iam.list_mfa_devices(UserName=username)
            if not mfa_devices['MFADevices']:
                users_without_mfa.append(username)
        except iam.exceptions.NoSuchEntityException:
            pass  # No console access

    return users_without_mfa

def check_open_security_groups():
    ec2 = boto3.client('ec2')
    sgs = ec2.describe_security_groups()['SecurityGroups']
    risky_sgs = []

    for sg in sgs:
        for permission in sg.get('IpPermissions', []):
            ip_ranges = permission.get('IpRanges', [])
            for ip_range in ip_ranges:
                if ip_range.get('CidrIp') == '0.0.0.0/0':
                    port = permission.get('FromPort')
                    if port in [22, 3389]:
                        risky_sgs.append({
                            'GroupId': sg['GroupId'],
                            'GroupName': sg['GroupName'],
                            'Port': port
                        })
    return risky_sgs

def check_security_groups_all_ports_open():
    ec2 = boto3.client('ec2')
    sgs = ec2.describe_security_groups()['SecurityGroups']
    fully_open_sgs = []

    for sg in sgs:
        for perm in sg.get('IpPermissions', []):
            for ip_range in perm.get('IpRanges', []):
                if ip_range.get('CidrIp') == '0.0.0.0/0':
                    from_port = perm.get('FromPort', -1)
                    to_port = perm.get('ToPort', -1)
                    if from_port == 0 and to_port == 65535:
                        fully_open_sgs.append(f"{sg['GroupId']} ({sg['GroupName']}) open to all ports")
    return fully_open_sgs

def check_unused_access_keys():
    iam = boto3.client('iam')
    users = iam.list_users()['Users']
    unused_keys = []

    for user in users:
        username = user['UserName']
        keys = iam.list_access_keys(UserName=username)['AccessKeyMetadata']
        for key in keys:
            key_id = key['AccessKeyId']
            last_used_info = iam.get_access_key_last_used(AccessKeyId=key_id)
            last_used_date = last_used_info['AccessKeyLastUsed'].get('LastUsedDate')
            if last_used_date:
                days_unused = (datetime.utcnow() - last_used_date.replace(tzinfo=None)).days
                if days_unused > 90:
                    unused_keys.append(f"{username} - {key_id} unused for {days_unused} days")
            else:
                unused_keys.append(f"{username} - {key_id} never used")
    return unused_keys

def check_public_s3_buckets():
    s3 = boto3.client('s3')
    buckets = s3.list_buckets()['Buckets']
    public_buckets = []

    for bucket in buckets:
        try:
            status = s3.get_bucket_policy_status(Bucket=bucket['Name'])
            if status['PolicyStatus']['IsPublic']:
                public_buckets.append(bucket['Name'])
        except Exception:
            pass  # Likely no policy, private by default

    return public_buckets

def check_root_account_usage():
    ct = boto3.client('cloudtrail')
    now = datetime.utcnow()
    past = now - timedelta(days=7)
    events = ct.lookup_events(
        LookupAttributes=[{'AttributeKey': 'Username', 'AttributeValue': 'root'}],
        StartTime=past,
        EndTime=now
    )
    return bool(events['Events'])

def check_cloudtrail_enabled_details():
    ct = boto3.client('cloudtrail')
    trails = ct.describe_trails()['trailList']
    not_enabled = []

    for trail in trails:
        if not trail.get('IsMultiRegionTrail', False) or not trail.get('LogFileValidationEnabled', False):
            not_enabled.append(trail['Name'])
    return not_enabled

def check_unused_elastic_ips():
    ec2 = boto3.client('ec2')
    addresses = ec2.describe_addresses()['Addresses']
    unused = [addr['PublicIp'] for addr in addresses if 'InstanceId' not in addr]
    return unused

def check_iam_full_admin_policies():
    iam = boto3.client('iam')
    users = iam.list_users()['Users']
    risky_users = []

    for user in users:
        attached_policies = iam.list_attached_user_policies(UserName=user['UserName'])['AttachedPolicies']
        for policy in attached_policies:
            version = iam.get_policy(PolicyArn=policy['PolicyArn'])['Policy']['DefaultVersionId']
            doc = iam.get_policy_version(PolicyArn=policy['PolicyArn'], VersionId=version)['PolicyVersion']['Document']
            statements = doc['Statement'] if isinstance(doc['Statement'], list) else [doc['Statement']]

            for stmt in statements:
                if stmt.get('Effect') == 'Allow' and stmt.get('Action') == '*' and stmt.get('Resource') == '*':
                    risky_users.append(user['UserName'])
                    break
    return risky_users

def check_public_rds_snapshots():
    rds = boto3.client('rds')
    snapshots = rds.describe_db_snapshots(SnapshotType='shared')['DBSnapshots']
    public_snapshots = []

    for snap in snapshots:
        attrs = rds.describe_db_snapshot_attributes(DBSnapshotIdentifier=snap['DBSnapshotIdentifier'])
        for attr in attrs['DBSnapshotAttributesResult']['DBSnapshotAttributes']:
            if attr['AttributeName'] == 'restore' and 'all' in attr['AttributeValues']:
                public_snapshots.append(snap['DBSnapshotIdentifier'])
    return public_snapshots

def check_password_rotation(max_age_days=60):
    iam = boto3.client('iam')
    users = iam.list_users()['Users']
    non_rotated = []

    for user in users:
        username = user['UserName']
        try:
            pwd_last_changed = user.get('PasswordLastUsed') or iam.get_user(UserName=username)['User'].get('PasswordLastChanged')
            if pwd_last_changed:
                days_since = (datetime.utcnow() - pwd_last_changed.replace(tzinfo=None)).days
                if days_since > max_age_days:
                    non_rotated.append(f"{username} - password last changed {days_since} days ago")
        except iam.exceptions.NoSuchEntityException:
            continue  # User might not have a console password
        except Exception as e:
            print(f"Error checking user {username}: {e}")
    return non_rotated



def send_email(subject, body):
    sns = boto3.client('sns')
    sns.publish(
        TopicArn=SNS_TOPIC_ARN,
        Subject=subject,
        Message=body
    )

def main():
    report = ""

    users_without_mfa = check_iam_users_without_mfa()
    if users_without_mfa:
        report += "IAM Users without MFA:\n" + "\n".join(users_without_mfa) + "\n\n"

    open_sgs = check_open_security_groups()
    if open_sgs:
        report += "Open Security Groups (SSH/RDP):\n"
        for sg in open_sgs:
            report += f"{sg['GroupId']} ({sg['GroupName']}) - Port {sg['Port']}\n"
        report += "\n"

    fully_open_sgs = check_security_groups_all_ports_open()
    if fully_open_sgs:
        report += "Security Groups open to all ports (0-65535):\n" + "\n".join(fully_open_sgs) + "\n\n"

    unused_keys = check_unused_access_keys()
    if unused_keys:
        report += "Unused Access Keys (>90 days):\n" + "\n".join(unused_keys) + "\n\n"

    public_buckets = check_public_s3_buckets()
    if public_buckets:
        report += "Public S3 Buckets:\n" + "\n".join(public_buckets) + "\n\n"

    risky_users = check_iam_full_admin_policies()
    if risky_users:
        report += "IAM Users with Full Admin Policies:\n" + "\n".join(risky_users) + "\n\n"

    if check_root_account_usage():
        report += "Root account login activity detected in last 7 days!\n\n"

    cloudtrail_issues = check_cloudtrail_enabled_details()
    if cloudtrail_issues:
        report += "CloudTrail issues:\n"
        for trail in cloudtrail_issues:
            report += f"Trail '{trail}' is not multi-region or validation disabled\n"
        report += "\n"

    unused_eips = check_unused_elastic_ips()
    if unused_eips:
        report += "Unused Elastic IPs:\n" + "\n".join(unused_eips) + "\n\n"

    public_snapshots = check_public_rds_snapshots()
    if public_snapshots:
        report += "Public RDS Snapshots:\n" + "\n".join(public_snapshots) + "\n\n"

    
    password_issues = check_password_rotation()
    if password_issues:
        report += "IAM Users with Passwords Not Rotated in Last 60 Days:\n"
        report += "\n".join(password_issues) + "\n\n"

    if report:
        send_email("AWS Security Alert Report", report)
        print("Alert email sent.")
    else:
        print("No security issues found.")

# Lambda entry point
def lambda_handler(event, context):
    main()
