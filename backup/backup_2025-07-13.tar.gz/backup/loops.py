diff_clouds_provider=["aws","azure","alibaba","salesforce","zoho"]

for i in diff_clouds_provider:
    print(i)

for i in range(0,2):
    print(i)
    